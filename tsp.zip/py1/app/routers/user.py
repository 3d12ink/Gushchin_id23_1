from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from app import schemas, crud, auth
from app.dependencies import get_db, get_current_user
from datetime import timedelta

router = APIRouter()

@router.post("/sign-up/", response_model=schemas.UserOut)
def sign_up(user_data: schemas.UserCreate, db: Session = Depends(get_db)):
    user = crud.get_user_by_email(db, user_data.email)
    if user:
        raise HTTPException(status_code=400, detail="Email already registered")
    new_user = crud.create_user(db, user_data.email, user_data.password)
    token = auth.create_access_token(data={"sub": new_user.email})
    return schemas.UserOut(id=new_user.id, email=new_user.email, token=token)

@router.post("/login/", response_model=schemas.UserOut)
def login(user_data: schemas.UserLogin, db: Session = Depends(get_db)):
    user = crud.get_user_by_email(db, user_data.email)
    if not user or not crud.verify_password(user_data.password, user.hashed_password):
        raise HTTPException(status_code=400, detail="Invalid credentials")
    token = auth.create_access_token(data={"sub": user.email}, expires_delta=timedelta(minutes=30))
    return schemas.UserOut(id=user.id, email=user.email, token=token)

@router.get("/users/me/", response_model=schemas.UserMe)
def read_users_me(current_user: schemas.UserMe = Depends(get_current_user)):
    return current_user