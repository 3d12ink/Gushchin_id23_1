from fastapi import APIRouter
from app.schemas import GraphRequest, PathResult

router = APIRouter()

@router.post("/shortest-path/", response_model=PathResult)
def solve_tsp(graph_data: GraphRequest):
    nodes = graph_data.graph.nodes
    edges = graph_data.graph.edges

    if not nodes:
        return PathResult(path=[], total_distance=0.0)

    n = len(nodes)
    visited = [False] * n
    path = []
    total_distance = 0

    current = 0  # начинаем с первого узла
    path.append(nodes[current])
    visited[current] = True

    for _ in range(n - 1):
        nearest = None
        min_dist = float('inf')
        for i in range(n):
            if not visited[i] and edges[current][i] < min_dist:
                min_dist = edges[current][i]
                nearest = i
        if nearest is not None:
            visited[nearest] = True
            path.append(nodes[nearest])
            total_distance += min_dist
            current = nearest

    # возвращаемся в начальную точку
    total_distance += edges[current][0]
    path.append(nodes[0])

    return PathResult(path=path, total_distance=total_distance)
