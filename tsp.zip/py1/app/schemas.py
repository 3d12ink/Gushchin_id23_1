from pydantic import BaseModel, EmailStr
from typing import List

class UserCreate(BaseModel):
    email: EmailStr
    password: str

class UserOut(BaseModel):
    id: int
    email: EmailStr
    token: str

    class Config:
        orm_mode = True

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class UserMe(BaseModel):
    id: int
    email: EmailStr

class Graph(BaseModel):
    nodes: List[int]
    edges: List[List[int]]

class GraphRequest(BaseModel):
    graph: Graph

class PathResult(BaseModel):
    path: List[int]
    total_distance: float