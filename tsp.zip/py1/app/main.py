from fastapi import FastAPI
from app.routers import user, tsp
from app.database import Base, engine

Base.metadata.create_all(bind=engine)

app = FastAPI()
app.include_router(user.router, prefix="/auth", tags=["user"])
app.include_router(tsp.router, tags=["tsp"])